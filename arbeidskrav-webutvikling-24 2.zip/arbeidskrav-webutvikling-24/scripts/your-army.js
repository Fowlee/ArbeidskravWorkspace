

document.addEventListener('DOMContentLoaded', () => {
    const warriorsContainer = document.querySelector(".warriorsDisplay");
    const machinesContainer = document.querySelector(".machinesDisplay");
    const animalsContainer = document.querySelector(".animalsDisplay");

    // Log containers to ensure they are selected
    console.log(warriorsContainer, machinesContainer, animalsContainer);

    const purchasedItems = JSON.parse(localStorage.getItem("purchasedItems")) || [];

    // Log purchased items to ensure data is retrieved correctly
    console.log("Purchased items:", purchasedItems);

    if (purchasedItems.length === 0) {
        console.log("No items found in localStorage.");
    }

    purchasedItems.forEach(item => {
        // Create a new div for each item
        const itemElement = document.createElement("div");
        itemElement.classList.add("itemBox");
        itemElement.innerHTML = `
            <img src="${item.image}" alt="${item.name} image" class="armyImg">
        `;

        console.log("Appending item:", item);

        // Append the item to the correct section based on its type
        if (item.type === 'warrior') {
            warriorsContainer.appendChild(itemElement);
        } else if (item.type === 'machine') {
            machinesContainer.appendChild(itemElement);
        } else if (item.type === 'animal') {
            animalsContainer.appendChild(itemElement);
        }
    });
});


