import ArmyModule from "./modules/armyModule.js";

alert("hello");